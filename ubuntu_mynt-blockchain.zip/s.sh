pm2 start ./myntd -x -- --rpc-bind-ip 0.0.0.0 --p2p-bind-ip 0.0.0.0 --confirm-external-bind
